package com.sharkstream.app.presentation.update

import android.app.DownloadManager
import com.sharkstream.app.R
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sharkstream.app.BuildConfig
import com.sharkstream.app.data.remote.GithubApi
import com.sharkstream.app.data.remote.GithubAssetDto
import com.sharkstream.app.data.remote.GithubReleaseDto
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

sealed interface UpdateUiState {
    data object Checking : UpdateUiState
    data class UpToDate(val latest: GithubReleaseDto?) : UpdateUiState
    data class Available(val release: GithubReleaseDto, val asset: GithubAssetDto?) : UpdateUiState
    data class Downloading(val release: GithubReleaseDto, val downloadedBytes: Long, val totalBytes: Long) : UpdateUiState {
        val progress: Float get() = if (totalBytes > 0) (downloadedBytes.toFloat() / totalBytes).coerceIn(0f, 1f) else 0f
    }
    data class ReadyToInstall(val release: GithubReleaseDto, val apk: File) : UpdateUiState
    data class Failed(val message: String, val release: GithubReleaseDto? = null) : UpdateUiState
}

@HiltViewModel
class UpdateViewModel @Inject constructor(
    private val githubApi: GithubApi,
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _uiState = MutableStateFlow<UpdateUiState>(UpdateUiState.Checking)
    val uiState: StateFlow<UpdateUiState> = _uiState.asStateFlow()

    val currentVersion: String = BuildConfig.VERSION_NAME

    private val downloads = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private var downloadId = -1L
    private var downloadJob: Job? = null

    init {
        checkForUpdate()
    }

    
    fun checkForUpdate() {
        viewModelScope.launch {
            _uiState.value = UpdateUiState.Checking
            _uiState.value = runCatching {
                val req = okhttp3.Request.Builder().url("https://pastebin.com/raw/vURCBq8E").build()
                val client = okhttp3.OkHttpClient()
                val resp = client.newCall(req).execute()
                val body = resp.body?.string().orEmpty()
                val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
                
                @kotlinx.serialization.Serializable
                data class PastebinRelease(
                    val versionName: String,
                    val versionCode: Int,
                    val apkUrl: String,
                    val assetName: String = "SharkStream.apk",
                    val releaseNotes: String = ""
                )
                val updateData = json.decodeFromString<PastebinRelease>(body)
                val releaseDto = GithubReleaseDto(
                    tagName = updateData.versionName,
                    name = "SharkStream " + updateData.versionName,
                    body = updateData.releaseNotes,
                    htmlUrl = updateData.apkUrl,
                    publishedAt = java.time.Instant.now().toString(),
                    assets = listOf(
                        GithubAssetDto(
                            name = updateData.assetName,
                            downloadUrl = updateData.apkUrl,
                            size = 45000000L
                        )
                    )
                )
                releaseDto
            }.fold(
                onSuccess = { release ->
                    if (isNewerVersion(release.tagName, currentVersion)) {
                        UpdateUiState.Available(release, pickAsset(release))
                    } else {
                        UpdateUiState.UpToDate(release)
                    }
                },
                onFailure = { 
                    UpdateUiState.Failed(context.getString(R.string.st_could_not_github))
                }
            )
        }
    }

    override fun onCleared() {
        downloadJob?.cancel()
    }

    private companion object {
        const val APK_MIME = "application/vnd.android.package-archive"
        const val PROGRESS_POLL_MS = 400L
        val SPLIT_ABIS = listOf("arm64-v8a", "armeabi-v7a", "x86_64", "x86")
    }
}
