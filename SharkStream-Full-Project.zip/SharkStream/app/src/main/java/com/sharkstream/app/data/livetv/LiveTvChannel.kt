package com.sharkstream.app.data.livetv

import kotlinx.serialization.Serializable

@Serializable
data class LiveTvChannel(
    val id: String,
    val name: String,
    val logo: String? = null,
    val streamUrl: String,
    val category: String = "Entertainment",
    val language: String = "Hindi",
    val country: String = "IN"
)
