package com.sharkstream.app.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Pure Deep Purple & Liquid Glass Palette
val SharkStreamDarkColorScheme = darkColorScheme(
    primary = Color(0xFF00E5FF),               // Neon Cyan (Shark accent)
    onPrimary = Color(0xFF06010F),
    primaryContainer = Color(0xFF1E0740),      // Deep Violet Container
    onPrimaryContainer = Color(0xFF00E5FF),
    secondary = Color(0xFF9D4EDD),             // Neon Purple
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFF280B52),
    onSecondaryContainer = Color(0xFFE0AAFF),
    tertiary = Color(0xFFFF2A85),              // Vivid Accent
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFF380720),
    onTertiaryContainer = Color(0xFFFFB0D0),
    background = Color(0xFF0A0216),            // Luxury Deep Midnight Purple
    onBackground = Color(0xFFFFFFFF),
    surface = Color(0xFF120524),               // Dark Purple Surface
    onSurface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFF220A45),        // Glass Card Surface
    onSurfaceVariant = Color(0xFFD4C8EB),
    surfaceContainerLowest = Color(0xFF070110),
    surfaceContainerLow = Color(0xFF0D031A),
    surfaceContainer = Color(0xFF17062E),      // Frosted Liquid Glass Base
    surfaceContainerHigh = Color(0xFF200940),
    surfaceContainerHighest = Color(0xFF2A0D52),
    outline = Color(0x6600E5FF),               // Glowing Cyan Outline
    outlineVariant = Color(0x339D4EDD)
)

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun OpenStreamTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false, // Disabled so Deep Purple is always active!
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        else -> SharkStreamDarkColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            @Suppress("DEPRECATION")
            window.statusBarColor = Color(0xFF0A0216).toArgb()
            @Suppress("DEPRECATION")
            window.navigationBarColor = Color(0xFF0A0216).toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialExpressiveTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = ExpressiveShapes,
        motionScheme = MotionScheme.expressive(),
        content = content
    )
}
