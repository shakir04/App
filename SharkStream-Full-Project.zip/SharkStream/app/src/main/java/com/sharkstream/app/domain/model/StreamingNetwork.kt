package com.sharkstream.app.domain.model

import androidx.annotation.DrawableRes
import com.sharkstream.app.R

enum class StreamingNetwork(
    val id: String,
    val displayName: String,
    val providerId: Int,
    val tag: String,
    val primaryColorHex: Long,
    val badgeText: String,
    @DrawableRes val logoRes: Int,
    val logoUrl: String
) {
    NETFLIX(
        "netflix", "Netflix", 8, "Originals & Blockbusters", 0xFFE50914, "N",
        R.drawable.ic_logo_netflix, "https://image.tmdb.org/t/p/w500/pbpMk2JmcoNnQwx5JGpXngfoWtp.jpg"
    ),
    PRIME_VIDEO(
        "prime", "Prime Video", 9, "Amazon Originals & Movies", 0xFF00A8E1, "PRIME",
        R.drawable.ic_logo_prime, "https://image.tmdb.org/t/p/w500/dQeAar5H991VYporEjUspolDarG.jpg"
    ),
    CRUNCHYROLL(
        "crunchyroll", "Crunchyroll", 283, "Anime Simulcasts & Series", 0xFFF47521, "CR",
        R.drawable.ic_logo_crunchyroll, "https://image.tmdb.org/t/p/w500/8Gt1iClBlzTeQs8WQm8UrCoIxnQ.jpg"
    ),
    HOTSTAR(
        "hotstar", "JioHotstar", 122, "Disney+, Marvel, Star & Live", 0xFF1F80E0, "HOTSTAR",
        R.drawable.ic_logo_hotstar, "https://image.tmdb.org/t/p/w500/7Fl8ylPDclt3ZYgNbW2t7rbZE9I.jpg"
    ),
    APPLE_TV(
        "appletv", "Apple TV+", 350, "Apple Original Series & Films", 0xFFFFFFFF, "TV+",
        R.drawable.ic_logo_appletv, "https://image.tmdb.org/t/p/w500/6uhKBfmtzFqOcLousHwZuzcrScK.jpg"
    ),
    JIOCINEMA(
        "jiocinema", "JioCinema", 220, "Indian Cinema & HBO Hits", 0xFFD9008D, "JIO",
        R.drawable.ic_logo_jiocinema, "https://image.tmdb.org/t/p/w500/t9c34G1S2K4vU7c3L2y75N5S6U5.jpg"
    ),
    ZEE5(
        "zee5", "ZEE5", 232, "Hindi Serials & Originals", 0xFFA142F4, "ZEE5",
        R.drawable.ic_logo_zee5, "https://image.tmdb.org/t/p/w500/ajbC1v3G4f4c8W2g4y5N6S7U8V9.jpg"
    );

    companion object {
        fun fromId(id: String): StreamingNetwork = entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: NETFLIX
    }
}
