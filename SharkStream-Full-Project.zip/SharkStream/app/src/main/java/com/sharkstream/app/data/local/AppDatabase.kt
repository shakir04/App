package com.sharkstream.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.sharkstream.app.data.local.dao.CustomListDao
import com.sharkstream.app.data.local.dao.DownloadDao
import com.sharkstream.app.data.local.dao.HiddenTitleDao
import com.sharkstream.app.data.local.dao.ReminderDao
import com.sharkstream.app.data.local.dao.TitleRatingDao
import com.sharkstream.app.data.local.dao.WatchLaterDao
import com.sharkstream.app.data.local.dao.IdMappingDao
import com.sharkstream.app.data.local.dao.ProfileDao
import com.sharkstream.app.data.local.dao.WatchProgressDao
import com.sharkstream.app.data.local.entity.CustomListEntity
import com.sharkstream.app.data.local.entity.CustomListItemEntity
import com.sharkstream.app.data.local.entity.DownloadEntity
import com.sharkstream.app.data.local.entity.HiddenTitleEntity
import com.sharkstream.app.data.local.entity.IdMappingEntity
import com.sharkstream.app.data.local.entity.ProfileEntity
import com.sharkstream.app.data.local.entity.ReminderEntity
import com.sharkstream.app.data.local.entity.TitleRatingEntity
import com.sharkstream.app.data.local.entity.WatchLaterEntity
import com.sharkstream.app.data.local.entity.WatchProgressEntity

@Database(
    entities = [
        WatchLaterEntity::class,
        DownloadEntity::class,
        IdMappingEntity::class,
        WatchProgressEntity::class,
        HiddenTitleEntity::class,
        CustomListEntity::class,
        CustomListItemEntity::class,
        ProfileEntity::class,
        ReminderEntity::class,
        TitleRatingEntity::class
    ],
    version = 9,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun watchLaterDao(): WatchLaterDao
    abstract fun downloadDao(): DownloadDao
    abstract fun idMappingDao(): IdMappingDao
    abstract fun watchProgressDao(): WatchProgressDao
    abstract fun hiddenTitleDao(): HiddenTitleDao
    abstract fun customListDao(): CustomListDao
    abstract fun profileDao(): ProfileDao
    abstract fun reminderDao(): ReminderDao
    abstract fun ratingDao(): TitleRatingDao
}
