package com.sharkstream.app.presentation.home

import com.sharkstream.app.presentation.components.SkeletonBox
import com.sharkstream.app.presentation.components.AnimeCard
import com.sharkstream.app.presentation.components.bottomContentPadding
import com.sharkstream.app.presentation.components.byWidth
import com.sharkstream.app.presentation.components.isCompactWidth
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import com.sharkstream.app.domain.model.Profile
import com.sharkstream.app.domain.model.StreamingNetwork
import com.sharkstream.app.presentation.profiles.ProfileSwitchButton
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LoadingIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.carousel.CarouselItemScope
import androidx.compose.material3.carousel.HorizontalCenteredHeroCarousel
import androidx.compose.material3.carousel.HorizontalMultiBrowseCarousel
import androidx.compose.material3.carousel.rememberCarouselState
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import coil3.compose.AsyncImage
import com.sharkstream.app.R
import com.sharkstream.app.data.remote.model.AnimeDto
import com.sharkstream.app.domain.model.WatchProgress
import com.sharkstream.app.ui.theme.ExpressiveShapes
import java.util.Locale
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun HomeScreen(
    onAnimeClick: (id: Int, mediaType: String) -> Unit,
    onNetworkClick: (StreamingNetwork) -> Unit = {},
    onResume: (WatchProgress) -> Unit,
    onOpenDetails: (mediaType: String, id: Int) -> Unit,
    onSettingsClick: () -> Unit,
    onUpdateClick: () -> Unit = {},
    profile: Profile? = null,
    onSwitchProfile: () -> Unit = {},
    viewModel: HomeViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val continueWatching by viewModel.continueWatching.collectAsState()
    val matches by viewModel.matches.collectAsState()
    val open: (AnimeDto) -> Unit = { onAnimeClick(it.id, if (it.isMovie) "movie" else "tv") }
    val snackbarHostState = remember { SnackbarHostState() }

    // Automatic Liquid Glass Update Popup Check
    var updatePrompt by remember { mutableStateOf<Pair<String, String>?>(null) }
    var updateApkUrl by remember { mutableStateOf<String?>(null) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                val client = okhttp3.OkHttpClient()
                val req = okhttp3.Request.Builder().url("https://pastebin.com/raw/vURCBq8E").build()
                val body = client.newCall(req).execute().body?.string().orEmpty()
                val jsonObj = kotlinx.serialization.json.Json.parseToJsonElement(body) as? kotlinx.serialization.json.JsonObject
                val remoteCode = jsonObj?.get("versionCode")?.toString()?.trim('"')?.toIntOrNull() ?: 0
                val remoteVer = jsonObj?.get("versionName")?.toString()?.trim('"').orEmpty()
                val notes = jsonObj?.get("releaseNotes")?.toString()?.trim('"')?.replace("\\n", "\n").orEmpty()
                val apk = jsonObj?.get("apkUrl")?.toString()?.trim('"').orEmpty()
                if (remoteCode > com.sharkstream.app.BuildConfig.VERSION_CODE && apk.isNotEmpty()) {
                    updateApkUrl = apk
                    updatePrompt = remoteVer to notes
                }
            }
        }
    }

    if (updatePrompt != null) {
        val (ver, notes) = updatePrompt!!
        androidx.compose.ui.window.Dialog(onDismissRequest = { updatePrompt = null }) {
            Surface(
                shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
                color = Color(0xEE14062B),
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    androidx.compose.ui.graphics.Brush.linearGradient(
                        listOf(Color(0xFF00E5FF), Color(0xFF9D4EDD), Color(0xFF00E5FF))
                    )
                ),
                modifier = Modifier.fillMaxWidth().padding(8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Surface(
                        shape = androidx.compose.foundation.shape.CircleShape,
                        color = Color(0x3300E5FF),
                        modifier = Modifier.size(64.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.SystemUpdate,
                                contentDescription = null,
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(34.dp)
                            )
                        }
                    }
                    Text(
                        text = "SharkStream " + ver + " Available",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    if (notes.isNotBlank()) {
                        Text(
                            text = notes,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFD4C8EB)
                        )
                    }
                    Button(
                        onClick = {
                            updatePrompt = null
                            onUpdateClick()
                        },
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF00E5FF),
                            contentColor = Color(0xFF06010F)
                        ),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Text("Update Now", fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }

    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val undoLabel = stringResource(R.string.action_undo)
    val hide: (AnimeDto) -> Unit = { anime ->
        viewModel.hideTitle(anime)
        scope.launch {
            val result = snackbarHostState.showSnackbar(
                message = context.getString(R.string.home_hidden_from_home, anime.name),
                actionLabel = undoLabel,
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) viewModel.unhideTitle(anime)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        when (val state = uiState) {
            HomeUiState.Loading -> HomeSkeleton()

            is HomeUiState.Error -> HomeError(onRetry = { viewModel.loadData() })

            is HomeUiState.Success -> PullToRefreshBox(
                isRefreshing = state.isRefreshing,
                onRefresh = viewModel::refresh,
                modifier = Modifier.fillMaxSize()
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    // Clears the floating toolbar and the mini player.
                    contentPadding = PaddingValues(bottom = bottomContentPadding)
                ) {
                    item(key = "hero") {
                        HeroSection(
                            items = state.hero,
                            onOpen = open,
                            onSettingsClick = onSettingsClick,
                            onUpdateClick = onUpdateClick,
                            profile = profile,
                            onSwitchProfile = onSwitchProfile,
                            onKidsTap = {
                                scope.launch { snackbarHostState.showSnackbar(context.getString(R.string.home_hold_avatar_kids)) }
                            }
                        )
                    }

                    
                    item(key = "streaming_networks") {
                        SectionHeader(title = "Streaming Networks")
                        StreamingNetworksRail(onNetworkClick = onNetworkClick)
                    }

                    if (continueWatching.isNotEmpty()) {
                        item(key = "continue_watching") {
                            SectionHeader(title = stringResource(R.string.home_continue_watching))
                            ContinueWatchingRail(
                                items = continueWatching,
                                onResume = onResume,
                                onOpenDetails = { onOpenDetails(it.mediaType, it.tmdbId) },
                                onRemove = viewModel::removeFromContinueWatching
                            )
                        }
                    }

                    if (matches.isNotEmpty()) {
                        item(key = "top-matches") {
                            SectionHeader(title = stringResource(R.string.match_rail))
                            MatchRail(matches = matches, onOpen = open)
                        }
                    }

                    state.rails.forEach { rail ->
                        item(key = rail.key) {
                            SectionHeader(title = rail.title)
                            when (rail.style) {
                                RailStyle.RANKED -> RankedRail(rail.items, open, hide)
                                RailStyle.LANDSCAPE -> LandscapeRail(rail.items, open, hide)
                                RailStyle.POSTER -> PosterRail(rail.items, open, hide)
                            }
                        }
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            // Above the floating toolbar and the mini player.
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = if (isCompactWidth) 180.dp else 100.dp)
        )
    }
}

// region Hero

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HeroSection(
    items: List<AnimeDto>,
    onOpen: (AnimeDto) -> Unit,
    onSettingsClick: () -> Unit,
    onUpdateClick: () -> Unit,
    profile: Profile?,
    onSwitchProfile: () -> Unit,
    onKidsTap: () -> Unit
) {
    Column(modifier = Modifier.statusBarsPadding()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, end = 8.dp, top = 8.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f)
            )
            // A kids profile keeps Settings and updates out of reach; leaving takes a hold on the avatar.
            if (profile?.isKids != true) {
                IconButton(onClick = onUpdateClick) {
                    Icon(Icons.Default.SystemUpdate, contentDescription = stringResource(R.string.action_check_for_updates))
                }
                IconButton(onClick = onSettingsClick) {
                    Icon(Icons.Default.Settings, contentDescription = stringResource(R.string.cd_settings))
                }
            }
            ProfileSwitchButton(profile = profile, onSwitch = onSwitchProfile, onKidsTap = onKidsTap)
        }

        if (items.isNotEmpty()) {
            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                if (maxWidth < 600.dp) {
                    HorizontalCenteredHeroCarousel(
                        state = rememberCarouselState { items.size },
                        itemSpacing = 8.dp,
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(480.dp)
                    ) { index ->
                        HeroCard(anime = items[index], rank = index + 1, onClick = { onOpen(items[index]) })
                    }
                } else {
                    // Tablets: several phone-sized poster cards side by side, not one huge banner.
                    HorizontalMultiBrowseCarousel(
                        state = rememberCarouselState { items.size },
                        preferredItemWidth = 320.dp,
                        itemSpacing = 8.dp,
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(440.dp)
                    ) { index ->
                        HeroCard(anime = items[index], rank = index + 1, onClick = { onOpen(items[index]) })
                    }
                }
            }
        }
    }
}

/** 0 for a sliver at the carousel's edge, 1 for the focused card; used to fade text in. */
@OptIn(ExperimentalMaterial3Api::class)
private val CarouselItemScope.focus: Float
    get() {
        val info = carouselItemDrawInfo
        return if (info.maxSize > info.minSize) {
            ((info.size - info.minSize) / (info.maxSize - info.minSize)).coerceIn(0f, 1f)
        } else {
            1f
        }
    }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CarouselItemScope.HeroCard(
    anime: AnimeDto,
    rank: Int,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .maskClip(ExpressiveShapes.extraLarge)
            .clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = "https://image.tmdb.org/t/p/w780${anime.posterPath}",
            contentDescription = anime.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0.45f to Color.Transparent,
                        1f to Color.Black.copy(alpha = 0.88f)
                    )
                )
        )
        // Text only belongs on the focused card; the side cards are slivers of artwork.
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(20.dp)
                .graphicsLayer { alpha = focus * focus },
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = ExpressiveShapes.small,
                color = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Text(
                    text = "#" + stringResource(R.string.home_rank_this_week, rank),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
            Text(
                text = anime.name,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black,
                color = Color.White,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            MetaLine(anime)
        }
    }
}

@Composable
private fun MetaLine(anime: AnimeDto) {
    val movieLabel = if (anime.isMovie) stringResource(R.string.details_movie) else null
    val genreLabel = anime.genreIds.orEmpty().firstOrNull { it != 16 }?.let { genreName(it) }
    val parts = buildList {
        anime.date.take(4).takeIf { it.length == 4 }?.let(::add)
        movieLabel?.let(::add)
        genreLabel?.let(::add)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        anime.voteAverage?.takeIf { it > 0 }?.let { rating ->
            Icon(
                Icons.Default.Star,
                contentDescription = null,
                tint = Color(0xFFFFC857),
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = String.format(Locale.US, " %.1f", rating) + if (parts.isNotEmpty()) "  ·  " else "",
                style = MaterialTheme.typography.labelLarge,
                color = Color.White
            )
        }
        Text(
            text = parts.joinToString("  ·  "),
            style = MaterialTheme.typography.labelLarge,
            color = Color.White.copy(alpha = 0.8f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// endregion

// region Rails

@Composable
private fun RankedRail(items: List<AnimeDto>, onOpen: (AnimeDto) -> Unit, onHide: (AnimeDto) -> Unit) {
    val posterWidth = byWidth(compact = 136.dp, medium = 156.dp, expanded = 168.dp)
    val numeralStyle = TextStyle(
        fontSize = (posterWidth.value * 0.97f).sp,
        fontWeight = FontWeight.Black,
        drawStyle = Stroke(width = 6f)
    )
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        itemsIndexed(items, key = { _, anime -> anime.id }) { index, anime ->
            var menuOpen by remember { mutableStateOf(false) }
            Box(modifier = Modifier.size(width = posterWidth + 48.dp, height = posterWidth / 0.68f + 14.dp)) {
                Text(
                    text = "${index + 1}",
                    style = numeralStyle,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .offset(y = 28.dp)
                )
                AsyncImage(
                    model = "https://image.tmdb.org/t/p/w342${anime.posterPath}",
                    contentDescription = anime.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .width(posterWidth)
                        .aspectRatio(0.68f)
                        .clip(ExpressiveShapes.medium)
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                        .titleClickable(anime, onOpen) { menuOpen = true }
                )
                NotInterestedMenu(menuOpen, onDismiss = { menuOpen = false }, onHide = { onHide(anime) })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LandscapeRail(items: List<AnimeDto>, onOpen: (AnimeDto) -> Unit, onHide: (AnimeDto) -> Unit) {
    HorizontalMultiBrowseCarousel(
        state = rememberCarouselState { items.size },
        preferredItemWidth = byWidth(compact = 300.dp, medium = 380.dp, expanded = 420.dp),
        itemSpacing = 8.dp,
        contentPadding = PaddingValues(horizontal = 16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(byWidth(compact = 188.dp, medium = 220.dp, expanded = 240.dp))
    ) { index ->
        val anime = items[index]
        var menuOpen by remember { mutableStateOf(false) }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .maskClip(ExpressiveShapes.large)
                .titleClickable(anime, onOpen) { menuOpen = true }
        ) {
            NotInterestedMenu(menuOpen, onDismiss = { menuOpen = false }, onHide = { onHide(anime) })
            AsyncImage(
                model = "https://image.tmdb.org/t/p/w780${anime.backdropPath}",
                contentDescription = anime.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(0.5f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.8f)))
            )
            Text(
                text = anime.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(14.dp)
                    .graphicsLayer { alpha = focus }
            )
        }
    }
}

@Composable
private fun PosterRail(items: List<AnimeDto>, onOpen: (AnimeDto) -> Unit, onHide: (AnimeDto) -> Unit) {    val posterWidth = byWidth(compact = 132.dp, medium = 152.dp, expanded = 164.dp)
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        itemsIndexed(items, key = { _, anime -> anime.id }) { _, anime ->
            var menuOpen by remember { mutableStateOf(false) }
            // Clipped to the artwork's shape so the press ripple follows the card; the title is
            // inset from the rounded bottom corners so they never cut into it.
            Column(
                modifier = Modifier
                    .width(posterWidth)
                    .clip(ExpressiveShapes.medium)
                    .titleClickable(anime, onOpen) { menuOpen = true }
                    .padding(bottom = 10.dp)
            ) {
                NotInterestedMenu(menuOpen, onDismiss = { menuOpen = false }, onHide = { onHide(anime) })
                AsyncImage(
                    model = "https://image.tmdb.org/t/p/w342${anime.posterPath}",
                    contentDescription = anime.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(0.68f)
                        .clip(ExpressiveShapes.medium)
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                )
                Text(
                    text = anime.name,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 8.dp, start = 6.dp, end = 6.dp)
                )
            }
        }
    }
}

/** Taste matches: poster cards with a match-% badge and the reason underneath. */
@Composable
private fun MatchRail(matches: List<MatchUi>, onOpen: (AnimeDto) -> Unit) {
    val posterWidth = byWidth(compact = 132.dp, medium = 152.dp, expanded = 164.dp)
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(matches, key = { it.key }) { match ->
            Column(modifier = Modifier.width(posterWidth)) {
                AnimeCard(
                    anime = match.item,
                    onClick = { onOpen(match.item) },
                    matchPercent = match.percent
                )
                match.becauseName?.let { name ->
                    Text(
                        text = stringResource(R.string.match_because, name),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 6.dp, start = 6.dp, end = 6.dp)
                    )
                }
            }
        }
    }
}

/** Tap opens the title; long-press opens its menu. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Modifier.titleClickable(anime: AnimeDto, onOpen: (AnimeDto) -> Unit, onLongPress: () -> Unit): Modifier {
    val haptics = LocalHapticFeedback.current
    return combinedClickable(
        onClickLabel = stringResource(R.string.misc_open_title, anime.name),
        onLongClickLabel = stringResource(R.string.misc_more_options),
        onLongClick = {
            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
            onLongPress()
        },
        onClick = { onOpen(anime) }
    )
}

@Composable
private fun NotInterestedMenu(expanded: Boolean, onDismiss: () -> Unit, onHide: () -> Unit) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(
            text = { Text(stringResource(R.string.home_not_interested)) },
            leadingIcon = { Icon(Icons.Default.VisibilityOff, contentDescription = null) },
            onClick = {
                onDismiss()
                onHide()
            }
        )
    }
}

// endregion

@Composable
fun SectionHeader(title: String, topPadding: Dp = 28.dp) {
    Text(
        text = title,
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Black,
        color = MaterialTheme.colorScheme.onBackground,
        modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = topPadding, bottom = 14.dp)
    )
}

@Composable
private fun HomeError(onRetry: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = stringResource(R.string.st_could_not_catalog),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = stringResource(R.string.home_check_connection),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = onRetry, shape = ExpressiveShapes.medium) {
            Text(stringResource(R.string.action_try_again))
        }
    }
}

/** TMDB genre ids that anime titles use (the TV and movie lists share most of them). */
@Composable
private fun genreName(id: Int): String? = when (id) {
    16 -> stringResource(R.string.genre_animation)
    10759 -> stringResource(R.string.genre_action_adventure)
    28 -> stringResource(R.string.genre_action)
    12 -> stringResource(R.string.genre_adventure)
    35 -> stringResource(R.string.genre_comedy)
    18 -> stringResource(R.string.genre_drama)
    10765 -> stringResource(R.string.genre_scifi_fantasy)
    14 -> stringResource(R.string.genre_fantasy)
    878 -> stringResource(R.string.genre_scifi)
    9648 -> stringResource(R.string.genre_mystery)
    10749 -> stringResource(R.string.genre_romance)
    80 -> stringResource(R.string.genre_crime)
    27 -> stringResource(R.string.genre_horror)
    53 -> stringResource(R.string.genre_thriller)
    10751 -> stringResource(R.string.genre_family)
    10762 -> stringResource(R.string.genre_kids)
    36 -> stringResource(R.string.genre_history)
    10402 -> stringResource(R.string.genre_music)
    else -> null
}

/** Mirrors the Home layout (title, hero, two shelves) so nothing jumps when content arrives. */
@Composable
private fun HomeSkeleton() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        SkeletonBox(
            modifier = Modifier
                .padding(start = 24.dp, top = 16.dp, bottom = 20.dp)
                .size(width = 180.dp, height = 32.dp),
            shape = ExpressiveShapes.small
        )
        SkeletonBox(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .height(420.dp),
            shape = ExpressiveShapes.extraLarge
        )
        repeat(2) {
            SkeletonBox(
                modifier = Modifier
                    .padding(start = 24.dp, top = 28.dp, bottom = 14.dp)
                    .size(width = 200.dp, height = 24.dp),
                shape = ExpressiveShapes.small
            )
            Row(
                modifier = Modifier.padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                repeat(4) {
                    SkeletonBox(modifier = Modifier.size(width = 132.dp, height = 194.dp))
                }
            }
        }
    }
}


@Composable
fun StreamingNetworksRail(
    onNetworkClick: (StreamingNetwork) -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
    ) {
        items(StreamingNetwork.entries, key = { it.id }) { net ->
            Surface(
                modifier = Modifier
                    .width(155.dp)
                    .height(74.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onNetworkClick(net) }
                    .border(
                        1.2.dp,
                        Brush.linearGradient(
                            listOf(
                                Color(net.primaryColorHex).copy(alpha = 0.9f),
                                Color(0x4400E5FF)
                            )
                        ),
                        RoundedCornerShape(20.dp)
                    ),
                shape = RoundedCornerShape(20.dp),
                color = Color(0x441B073A)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AsyncImage(
                        model = net.logoUrl,
                        placeholder = painterResource(net.logoRes),
                        error = painterResource(net.logoRes),
                        contentDescription = net.displayName,
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = net.displayName,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Watch Now",
                            color = Color(0xFF00E5FF),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}
