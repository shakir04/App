package com.sharkstream.app.presentation.livetv

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sharkstream.app.data.livetv.LiveTvChannel
import com.sharkstream.app.data.livetv.LiveTvRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface LiveTvUiState {
    data object Loading : LiveTvUiState
    data class Success(val channels: List<LiveTvChannel>, val selectedCategory: String) : LiveTvUiState
    data class Error(val message: String) : LiveTvUiState
}

@HiltViewModel
class LiveTvViewModel @Inject constructor(
    private val repository: LiveTvRepository
) : ViewModel() {

    private val _channels = MutableStateFlow<List<LiveTvChannel>>(emptyList())
    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isLoading = MutableStateFlow(true)

    val categories = listOf("All", "News", "Entertainment", "Movies", "Music", "Sports")

    val uiState: StateFlow<LiveTvUiState> = combine(
        _channels, _selectedCategory, _searchQuery, _isLoading
    ) { channels, category, query, loading ->
        if (loading && channels.isEmpty()) {
            LiveTvUiState.Loading
        } else {
            val filtered = channels.filter { ch ->
                val matchesCat = category == "All" || ch.category.equals(category, ignoreCase = true)
                val matchesQuery = query.isBlank() || ch.name.contains(query, ignoreCase = true)
                matchesCat && matchesQuery
            }
            LiveTvUiState.Success(filtered, category)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LiveTvUiState.Loading)

    init {
        loadChannels()
    }

    fun loadChannels(force: Boolean = false) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val list = repository.getChannels(force)
                _channels.value = list
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }
}
