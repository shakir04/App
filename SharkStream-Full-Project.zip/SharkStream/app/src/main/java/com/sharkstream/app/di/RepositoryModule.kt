package com.sharkstream.app.di

import com.sharkstream.app.data.repository.AnimeRepositoryImpl
import com.sharkstream.app.data.repository.DownloadRepositoryImpl
import com.sharkstream.app.data.repository.WatchLaterRepositoryImpl
import com.sharkstream.app.data.repository.WatchProgressRepositoryImpl
import com.sharkstream.app.data.repository.CombinedSubtitleRepository
import com.sharkstream.app.domain.repository.SubtitleRepository
import com.sharkstream.app.data.extensions.ExtensionRepositoryImpl
import com.sharkstream.app.domain.repository.AnimeRepository
import com.sharkstream.app.domain.repository.DownloadRepository
import com.sharkstream.app.domain.repository.ExtensionRepository
import com.sharkstream.app.domain.repository.WatchLaterRepository
import com.sharkstream.app.domain.repository.WatchProgressRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    abstract fun bindAnimeRepository(
        animeRepositoryImpl: AnimeRepositoryImpl
    ): AnimeRepository

    @Binds
    abstract fun bindWatchLaterRepository(
        watchLaterRepositoryImpl: WatchLaterRepositoryImpl
    ): WatchLaterRepository

    @Binds
    abstract fun bindDownloadRepository(
        downloadRepositoryImpl: DownloadRepositoryImpl
    ): DownloadRepository

    @Binds
    abstract fun bindExtensionRepository(
        extensionRepositoryImpl: ExtensionRepositoryImpl
    ): ExtensionRepository

    @Binds
    abstract fun bindWatchProgressRepository(
        watchProgressRepositoryImpl: WatchProgressRepositoryImpl
    ): WatchProgressRepository

    @Binds
    abstract fun bindSubtitleRepository(
        combinedSubtitleRepository: CombinedSubtitleRepository
    ): SubtitleRepository
}
