package com.sharkstream.app.data.livetv

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.regex.Pattern
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LiveTvRepository @Inject constructor(
    private val okHttpClient: OkHttpClient,
    @ApplicationContext private val context: Context
) {
    private var cachedChannels: List<LiveTvChannel> = emptyList()

    suspend fun getChannels(forceRefresh: Boolean = false): List<LiveTvChannel> = withContext(Dispatchers.IO) {
        if (!forceRefresh && cachedChannels.isNotEmpty()) {
            return@withContext cachedChannels
        }

        val remoteChannels = fetchFromM3u()
        if (remoteChannels.isNotEmpty()) {
            cachedChannels = remoteChannels
            return@withContext remoteChannels
        }

        val defaultChannels = getDefaultHindiChannels()
        cachedChannels = defaultChannels
        defaultChannels
    }

    private fun fetchFromM3u(): List<LiveTvChannel> {
        val urls = listOf(
            "https://iptv-org.github.io/iptv/languages/hin.m3u",
            "https://iptv-org.github.io/iptv/countries/in.m3u",
            "https://iptv-org.github.io/iptv/index.m3u"
        )

        for (url in urls) {
            try {
                val req = Request.Builder().url(url).build()
                val resp = okHttpClient.newCall(req).execute()
                val body = resp.body?.string().orEmpty()
                if (body.contains("#EXTM3U")) {
                    val parsed = parseM3u(body)
                    if (parsed.isNotEmpty()) return parsed
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return emptyList()
    }

    private fun parseM3u(content: String): List<LiveTvChannel> {
        val channels = mutableListOf<LiveTvChannel>()
        val lines = content.lines()
        var currentName = ""
        var currentLogo: String? = null
        var currentCategory = "Entertainment"

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.startsWith("#EXTINF:")) {
                currentName = ""
                currentLogo = null
                currentCategory = "Entertainment"

                val logoMatch = Pattern.compile("tvg-logo=\"([^\"]*)\"").matcher(trimmed)
                if (logoMatch.find()) {
                    currentLogo = logoMatch.group(1)
                }

                val groupMatch = Pattern.compile("group-title=\"([^\"]*)\"").matcher(trimmed)
                if (groupMatch.find()) {
                    val rawGroup = groupMatch.group(1).trim()
                    currentCategory = mapCategory(rawGroup)
                }

                val commaIdx = trimmed.lastIndexOf(',')
                if (commaIdx != -1 && commaIdx < trimmed.length - 1) {
                    currentName = trimmed.substring(commaIdx + 1).trim()
                }
            } else if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
                if (currentName.isNotEmpty()) {
                    val isHindi = isHindiRelevant(currentName, currentCategory)
                    if (isHindi) {
                        channels.add(
                            LiveTvChannel(
                                id = "ch_${channels.size}_" + currentName.hashCode(),
                                name = currentName,
                                logo = currentLogo,
                                streamUrl = trimmed,
                                category = currentCategory,
                                language = "Hindi",
                                country = "IN"
                            )
                        )
                    }
                }
                currentName = ""
            }
        }
        return if (channels.isNotEmpty()) channels else getDefaultHindiChannels()
    }

    private fun isHindiRelevant(name: String, category: String): Boolean {
        val lower = name.lowercase()
        val hindiKeywords = listOf(
            "aaj tak", "ndtv", "abp", "india tv", "republic", "zee", "news18",
            "bharat", "samachar", "hindustan", "sansad", "dd", "doordarshan",
            "b4u", "mastiii", "9x", "dangal", "cinema", "bollywood", "music",
            "sports", "hindi", "star", "sony", "colors", "goldmines"
        )
        return hindiKeywords.any { lower.contains(it) } || category == "News" || category == "Entertainment"
    }

    private fun mapCategory(raw: String): String {
        val l = raw.lowercase()
        return when {
            l.contains("news") || l.contains("samachar") -> "News"
            l.contains("movie") || l.contains("cinema") -> "Movies"
            l.contains("music") || l.contains("sangeet") -> "Music"
            l.contains("sport") || l.contains("cricket") -> "Sports"
            else -> "Entertainment"
        }
    }

    private fun getDefaultHindiChannels(): List<LiveTvChannel> {
        return listOf(
            LiveTvChannel(
                id = "aaj_tak",
                name = "Aaj Tak News Live",
                logo = "https://upload.wikimedia.org/wikipedia/commons/2/28/Aaj_Tak_logo.png",
                streamUrl = "https://feeds.intoday.in/aajtak/api/livetv/master.m3u8",
                category = "News"
            ),
            LiveTvChannel(
                id = "ndtv_india",
                name = "NDTV India Live",
                logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/NDTV_India_logo.svg/512px-NDTV_India_logo.svg.png",
                streamUrl = "https://ndtvindiaelemarchana.akamaized.net/hls/live/2003679-b/ndtvindia/livefeed/master.m3u8",
                category = "News"
            ),
            LiveTvChannel(
                id = "abp_news",
                name = "ABP News Hindi",
                logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/6/60/ABP_News_logo.svg/512px-ABP_News_logo.svg.png",
                streamUrl = "https://abp-i.akamaihd.net/hls/live/765529/abpnews/master.m3u8",
                category = "News"
            ),
            LiveTvChannel(
                id = "india_tv",
                name = "India TV Live",
                logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/India_TV_logo.svg/512px-India_TV_logo.svg.png",
                streamUrl = "https://indiatvnews-live.akamaized.net/hls/live/2042171/indiatv/master.m3u8",
                category = "News"
            ),
            LiveTvChannel(
                id = "republic_bharat",
                name = "Republic Bharat Live",
                logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Republic_Bharat_Logo.svg/512px-Republic_Bharat_Logo.svg.png",
                streamUrl = "https://republic.akamaized.net/hls/live/2034925/bharat/master.m3u8",
                category = "News"
            ),
            LiveTvChannel(
                id = "dd_news",
                name = "DD News Live",
                logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1a/DD_News_Logo.svg/512px-DD_News_Logo.svg.png",
                streamUrl = "https://content.uplink.stream/ddnews/index.m3u8",
                category = "News"
            ),
            LiveTvChannel(
                id = "dd_sports",
                name = "DD Sports HD Live",
                logo = "https://upload.wikimedia.org/wikipedia/en/thumb/4/4e/DD_Sports_logo.svg/512px-DD_Sports_logo.svg.png",
                streamUrl = "https://content.uplink.stream/ddsports/index.m3u8",
                category = "Sports"
            ),
            LiveTvChannel(
                id = "b4u_movies",
                name = "B4U Movies Hindi",
                logo = "https://upload.wikimedia.org/wikipedia/en/thumb/f/f7/B4U_Movies_logo.svg/512px-B4U_Movies_logo.svg.png",
                streamUrl = "https://b4umovies-kalliope.akamaized.net/hls/live/2012130/b4umovies/master.m3u8",
                category = "Movies"
            ),
            LiveTvChannel(
                id = "b4u_music",
                name = "B4U Music Hits",
                logo = "https://upload.wikimedia.org/wikipedia/en/thumb/b/b3/B4U_Music_logo.svg/512px-B4U_Music_logo.svg.png",
                streamUrl = "https://b4umusic-kalliope.akamaized.net/hls/live/2012131/b4umusic/master.m3u8",
                category = "Music"
            ),
            LiveTvChannel(
                id = "9xm",
                name = "9XM Bollywood Music",
                logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/9XM_Logo.svg/512px-9XM_Logo.svg.png",
                streamUrl = "https://d2q8p4pe5ucc4q.cloudfront.net/out/v1/9xm/index.m3u8",
                category = "Music"
            ),
            LiveTvChannel(
                id = "dangal_tv",
                name = "Dangal TV Entertainment",
                logo = "https://upload.wikimedia.org/wikipedia/en/thumb/9/9f/Dangal_TV_Logo.png/512px-Dangal_TV_Logo.png",
                streamUrl = "https://dangal-live.akamaized.net/hls/live/2026852/dangaltv/master.m3u8",
                category = "Entertainment"
            )
        )
    }
}
