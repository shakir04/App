package com.sharkstream.app.presentation.network

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sharkstream.app.data.remote.model.AnimeDto
import com.sharkstream.app.domain.model.StreamingNetwork
import com.sharkstream.app.domain.repository.AnimeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface NetworkContentUiState {
    data object Loading : NetworkContentUiState
    data class Success(val titles: List<AnimeDto>, val selectedFilter: String) : NetworkContentUiState
    data class Error(val message: String) : NetworkContentUiState
}

@HiltViewModel
class NetworkContentViewModel @Inject constructor(
    private val repository: AnimeRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    val networkId: String = savedStateHandle["networkId"] ?: "netflix"
    val networkName: String = savedStateHandle["networkName"] ?: "Netflix"
    val network: StreamingNetwork = StreamingNetwork.fromId(networkId)

    private val _uiState = MutableStateFlow<NetworkContentUiState>(NetworkContentUiState.Loading)
    val uiState: StateFlow<NetworkContentUiState> = _uiState.asStateFlow()

    private val _filter = MutableStateFlow("all")
    val filter: StateFlow<String> = _filter.asStateFlow()

    val filterOptions = listOf("all" to "All", "movies" to "Movies", "series" to "Series")

    init {
        loadContent("all")
    }

    fun setFilter(filterType: String) {
        _filter.value = filterType
        loadContent(filterType)
    }

    fun loadContent(filterType: String = _filter.value) {
        viewModelScope.launch {
            _uiState.value = NetworkContentUiState.Loading
            repository.discoverByNetwork(network.providerId, filterType)
                .onSuccess { list ->
                    _uiState.value = NetworkContentUiState.Success(list, filterType)
                }
                .onFailure { error ->
                    _uiState.value = NetworkContentUiState.Error(error.message ?: "Failed to load content")
                }
        }
    }
}
