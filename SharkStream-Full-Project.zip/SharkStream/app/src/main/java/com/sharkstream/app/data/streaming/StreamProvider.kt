package com.sharkstream.app.data.streaming

import com.sharkstream.app.domain.model.MediaIdentity
import com.sharkstream.app.domain.model.VideoServer

interface StreamProvider {
    val id: String
    val displayName: String
    val priority: Int
    val isEnabled: Boolean
    val isFallback: Boolean
        get() = false

    suspend fun resolve(identity: MediaIdentity): Result<List<VideoServer>>
}
