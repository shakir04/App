# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile
# Named only in the manifest (Cast framework options), so R8 can't see it's used.
-keep class com.sharkstream.app.data.cast.CastOptionsProvider { *; }

# Release: strip verbose logging (14+ files use android.util.Log).
# Keep warnings/errors so crash triage still has signal.
-assumenosideeffects class android.util.Log {
    public static *** v(...);
    public static *** d(...);
    public static *** i(...);
}


# Keep all SharkStream data models, LiveTV, Update & Serialization classes safe from R8 stripping
-keep class com.sharkstream.app.data.** { *; }
-keep class com.sharkstream.app.domain.model.** { *; }
-keep class com.sharkstream.app.presentation.update.** { *; }
-keepattributes *Annotation*, InnerClasses
-dontwarn kotlinx.serialization.**
