# SharkStream 4.9.417

Movies, series and anime streaming app for Android.  
Rebranded and customized by **mr.shakir_01**  
Instagram: https://instagram.com/mr.shakir_01  

---

### Customizations & Features:
* **Package Name:** `com.sharkstream.app` (Multi-install enabled)
* **Default DNS:** Cloudflare 1.1.1.1 DNS over HTTPS (DoH) enabled by default
* **Playback Startup:** Instant 500ms playback startup buffer
* **Audio & Subtitles:** Default preferred audio and subtitles set to Hindi (`hi`, `hin`)
* **Quality Cap:** No limit (unlimited up to 4K Ultra HD)
* **Download System:** Smart Downloads enabled by default
* **Update System:** Direct integration with Pastebin (`https://pastebin.com/raw/vURCBq8E`) and direct APK delivery
* **Theme:** Deep Purple palette with frosted Liquid Glass accents
* **Branding:** Glowing Cyan/Purple Shark logo across all mipmap resolutions and Android TV banner

---

### How to Build the APK:

#### Option 1: 1-Click Cloud Build (GitHub Actions)
1. Push this folder to your GitHub repository.
2. Open the **Actions** tab on GitHub.
3. Select **Build SharkStream Release APK** and click **Run workflow**.
4. Within 2-3 minutes, your compiled `SharkStream-APK` will be available in the **Artifacts** section!

#### Option 2: Local Build (Terminal)
In this root directory, run:
```bash
./gradlew assembleDebug
```
The output APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`
